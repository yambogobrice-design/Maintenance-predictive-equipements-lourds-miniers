"""End-to-end project orchestration used by notebooks and the dashboard."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .data_loader import build_demo_machine_snapshot, prepare_raw_datasets
from .evaluation import evaluate_classifier, evaluate_regressor
from .feature_engineering import build_feature_table, get_feature_columns, temporal_train_test_split
from .models import reduce_training_frame, save_model_artifacts, train_classifiers, train_rul_models
from .utils import ensure_directory, save_dataframe, save_json


def run_full_training(project_root: str | Path) -> dict[str, object]:
    """Execute the full M3 pipeline and persist the main artifacts."""

    project_root = Path(project_root)
    bundle = prepare_raw_datasets(project_root)
    features = build_feature_table(bundle, project_root)
    modelling_df = reduce_training_frame(features, "failure_within_24h", stride=120, keep_positive=True)
    train_df, test_df = temporal_train_test_split(modelling_df)
    feature_columns = get_feature_columns(features)

    classifier_artifacts = train_classifiers(train_df)
    regressor_artifacts = train_rul_models(train_df)

    model_dir = ensure_directory(project_root / "models")
    save_model_artifacts({**classifier_artifacts, **regressor_artifacts}, model_dir)

    metrics_dir = ensure_directory(project_root / "data" / "processed")
    classifier_metrics = {}
    regressor_metrics = {}
    prediction_frames: list[pd.DataFrame] = []

    for name, artifact in classifier_artifacts.items():
        metrics, preds = evaluate_classifier(artifact, test_df, feature_columns)
        classifier_metrics[name] = metrics
        prediction_frames.append(preds.assign(model_name=name))

    for name, artifact in regressor_artifacts.items():
        metrics, preds = evaluate_regressor(artifact, test_df, feature_columns)
        regressor_metrics[name] = metrics
        prediction_frames.append(preds.assign(model_name=name))

    combined_predictions = features.copy()
    if "rf" in classifier_artifacts:
        rf_metrics, rf_preds = evaluate_classifier(classifier_artifacts["rf"], test_df, feature_columns)
        test_merge = rf_preds[["datetime", "machineID", "predicted_failure_probability", "predicted_failure_label"]]
        combined_predictions = combined_predictions.merge(test_merge, on=["datetime", "machineID"], how="left")
    else:
        combined_predictions["predicted_failure_probability"] = 0.0
        combined_predictions["predicted_failure_label"] = 0

    if "rf_rul" in regressor_artifacts:
        rul_metrics, rul_preds = evaluate_regressor(regressor_artifacts["rf_rul"], test_df, feature_columns)
        rul_merge = rul_preds[["datetime", "machineID", "predicted_rul"]]
        combined_predictions = combined_predictions.merge(rul_merge, on=["datetime", "machineID"], how="left")
    else:
        combined_predictions["predicted_rul"] = combined_predictions["rul_hours"]

    combined_predictions["predicted_failure_probability"] = combined_predictions["predicted_failure_probability"].fillna(0.0)
    combined_predictions["predicted_failure_label"] = combined_predictions["predicted_failure_label"].fillna(0).astype(int)
    combined_predictions["predicted_rul"] = combined_predictions["predicted_rul"].fillna(combined_predictions["rul_hours"].fillna(combined_predictions["rul_hours"].median()))

    save_dataframe(combined_predictions, metrics_dir / "fleet_predictions.csv")
    save_dataframe(build_demo_machine_snapshot(combined_predictions), metrics_dir / "fleet_snapshot.csv")
    save_json({"classification": classifier_metrics, "regression": regressor_metrics}, metrics_dir / "metrics_summary.json")
    save_dataframe(pd.concat(prediction_frames, ignore_index=True, sort=False), metrics_dir / "all_predictions.csv")

    return {
        "bundle": bundle,
        "features": features,
        "train_df": train_df,
        "test_df": test_df,
        "feature_columns": feature_columns,
        "classifier_artifacts": classifier_artifacts,
        "regressor_artifacts": regressor_artifacts,
        "classifier_metrics": classifier_metrics,
        "regressor_metrics": regressor_metrics,
        "combined_predictions": combined_predictions,
    }
